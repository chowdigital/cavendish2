<?php if(is_page('events')) {
	$category_id = 3;
	echo "<div class=\"loop loop-events\">";
} else {
	$category_id = 2;
	echo "<div class=\"loop loop-home\">";
	/*
	 * Slider
	 */
	$slides = array( 'post_type' => 'slide', 'posts_per_page' => 5 );
	$slides = get_posts( $slides );
	$i = 0;
	echo '<div class="slider post-45">';
	foreach ( $slides as $post ) : $i++; ?>
		<div class="slide <?php if($i == 1) echo 'current'; ?>" data-full="<?php echo the_compulsory_thumbnail('large','return',$post->ID);?>" alt="35 new Cavendish">
			<?php if($i == 1) echo '<span>'. the_compulsory_thumbnail('large','echo',$post->ID).'</span>'; ?>
		</div>
	<?php endforeach; 
	echo '</div>';
	
	/*
	 * Text
	 */
		$home_id = 2;
		$post = get_post($home_id);
		echo '<div class="intro">'.apply_filters('the_content', $post->post_content).'</div>'; 
}

/*
 * Blocks
 */
$blocks = array( 'post_type' => 'block', 'posts_per_page' => -1, 'category' => $category_id );
$blocks = get_posts( $blocks );
echo '<div class="block-container">';
foreach ( $blocks as $post ) : setup_postdata( $post ); ?>
	<h2 class="block-title block-title-<?php echo $post->post_name; ?>"><?php the_title(); ?></h2>
	<?php
		$block_function = 'block_' . str_replace('-','_',$post->post_name);
		if(function_exists($block_function)) 
			$block_function();
		elseif(has_post_thumbnail()) {
			echo '<div class="block-content block-'.$post->post_name.'">';
			if ( has_excerpt() ) echo '<a href="'.get_the_excerpt().'">';
			else echo '<a href="'.get_permalink( $post->ID ).'">';
			the_post_thumbnail('medium');
			if ( has_excerpt() ) echo '</a>';
			echo '</div>';
		} else echo '<div class="block-content">Please, choose an image <br>and write a link <br>for this block</div>';		
	?>
<?php endforeach; 
echo '</div>';
wp_reset_postdata();
?>
	<section class="subsection"></section>
</div>