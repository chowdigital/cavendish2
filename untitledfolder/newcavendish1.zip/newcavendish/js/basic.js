var h,hh,device='phone';
/* secMapping "
 * 	if(the same) do nothing
	if (empty or home or events) replace all wrapper
	else load section 
}
*/

var resizeScreen = function() { //inicio y cambio de tamaÃ±o
	hh = $('header').height();
	h = $(window).height() - hh;
	if(device == 'phone') $('main').height(h);
	else if(device == 'desktop') $('.subsection').height($(document).height());
	$('#menuview').height(h - 20);
};

var CAVENDISH = CAVENDISH || {};


var getSec = function(href) { 
	var sec = href.replace(SITE_URL,'').replace(/[\w-\.:]*?\/?([a-z0-9-\/]*)\/(#|\?.*)?$/,'$1');
	if(sec=='/' || sec=='' || sec==SITE_URL+'/' || sec==SITE_URL) sec = 'home';
	return sec;
};
	

var openSec = function(e, forcehref,openAfter) {
	if(forcehref !== undefined) { // if openSec was called directly as a function
		var href = forcehref;
	} else { // or openSec was called by a html link
		var href = $(this).attr('href');
		// if we are dealing with an extenral link let's stop the function
		if (href.substring(0, 4) == "http" && href.substring(0, SITE_URL.length) != SITE_URL) return;
		else e.preventDefault();
		console.log('href: '+href);
		if(href=='#') return; 
	}

	var sec = getSec(href); // define sec
	// open the new section if it's not in the current one
	
	if($('body').attr('data-url').replace(/\/$/,'') != href.replace(/\/$/,'')) {
		$('#lightGallery-outer, #menuview').remove();
		// 1st step: change url:
		if(window.history && window.history.pushState) history.pushState({sec:sec}, sec, href);
		// 2nd step: process actions:
		var dontAjax,limit;
		if(sec=='home' || sec=='events') { // Are we replacing one of the 2 loop areas?
			$('header nav').removeClass('open');
			if(sec=='home' && $('.loop').hasClass('loop-home') ||
			sec=='events' && $('.loop').hasClass('loop-events')) {
				// the area is already loaded, just close the subsection
				dontAjax = true;
				$('body').removeClass('open');
				setTimeout(function(){$('.subsection > *').remove();},600);
				if(sec=='home') $('body').attr('class',sec);
				$('body').attr('data-url',href);
			} else {
				// remove the differente area, and open the new one
				$('.loop').addClass('delete').fadeOut(600,function(){
					$(this).remove();
				});
				if(sec == 'home') href = SITE_URL+'/home/'
				var callback = function(contents) {
					$('body').removeClass('open');
					$('main .wrapper').append(contents);
					if(openAfter !== undefined) {
						console.log('openAfter: '+openAfter);
						openSec(e,openAfter);
					}
				}
			}
		} else { // Are we replacing a subsection?
			var is_event = sec.replace(/\/([a-z0-9-\/]+)$/,'')=='event' ? true : false;
			if(is_event && !$('.loop').hasClass('loop-events')) { //we're not in the correct area, open events
				openSec(e,SITE_URL + '/events/',href);
				dontAjax = true;
			} else if(!is_event && !$('.loop').hasClass('loop-home')) { //we're not in the correct area, open home
				openSec(e,SITE_URL + '/',href);
				dontAjax = true;
			}
			$('.subsection').removeClass('show').fadeOut(2000,function(){
				$(this).remove();
			});
			var callback = function(contents) {
				$('.subsection').addClass('no-overlay');
				$('main .wrapper .loop').append($('.subsection',contents));
				$('body').addClass('open');
			}
		}
		// 3rd step: process actions:
		if(!dontAjax){
				$('body').addClass('loading');
				$.get( href+'?method=ajax', function( data ) {
					data = JSON.parse(data);
					$('title').text(data.title);
					$('body').attr('class',data.bodyclasses);
					var contents = $.parseHTML( data.contents );
					if(sec!='gallery') $('a',contents).on('click', openSec);
					callback(contents);
					if(device == 'phone') $('main').height(h);
					$('body').attr('data-url',href);
					$('body').removeClass('loading');
					loadSec(sec);
				}, "html");
		}
	}
};

var loadSec = function(sec) {
	console.log('loadSec mob: '+sec);
};
var toggleMenu = function(e) {
	e.preventDefault();
	$('header nav').toggleClass('open');
};

window.onpopstate = function(event) {
	console.log('pop: '+location.href);
	if(location.href.slice(-1) != '#') openSec(event,location.href);
};

$(window).resize(resizeScreen);

$(document).ready(function(){
    $('header a').on('click touchstart', openSec);
    $('main a').on('click', openSec);
    $('nav button').on('click touchstart', toggleMenu);
    resizeScreen();
    //cachearImg();
});
$(window).load(resizeScreen);



