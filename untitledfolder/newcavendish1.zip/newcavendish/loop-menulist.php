<div class="loop">
	<section class="subsection show">
		<article id="post-<?php the_ID(); ?>" <?php post_class('menu-list'); ?>>
			<ul>
			<?php // Left Menu list
			$menus = array( 'post_type' => 'menu', 'posts_per_page' => -1 );
			$menus = get_posts( $menus );
				foreach ( $menus as $post ) : ?>
				<li>
					<h2><a href="<?php echo get_permalink( $post->ID ); ?>" class="menu-link"><?php echo $post->post_title; ?> <span>&gt;</span></a></h2>
				</li><?php endforeach; ?>
			</ul>
			<?php // Right Extra link block
			$blocks = array( 'post_type' => 'block', 'posts_per_page' => 1, 'category' => 8 );
			$blocks = get_posts( $blocks );
			if($blocks) { foreach ( $blocks as $post ) : setup_postdata( $post ); ?>
				<?php $image_attributes = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'medium'); ?>
					<div class="block-content block-menu block-<?php echo $post->post_name; ?> menu-extra-link" style="background-image:url(<?php echo $image_attributes[0];?>)">
						<h1><a href="<?php echo get_the_excerpt(); ?>" class="menu-link"><strong><?php echo $post->post_title; ?></strong></a></h1>
					</div>
			<?php endforeach;
			} else echo '<div class="menu-extra-link" style="background:#fff"></div>'; ?>
		</article>
	</section>
</div>