<div class="loop">
	<section class="subsection show">
   		<link rel="stylesheet"  href="<?php echo get_stylesheet_directory_uri() ?>/lightgallery/css/lightGallery.css"/>
		<div id="post-gallery">
			<ul id="auto-loop" class="gallery"><?php 
				$posts = array( 'post_type' => 'attachment', 'posts_per_page' => -1, 'cat' => 7 );
				$posts = get_posts( $posts );
				foreach ( $posts as $post ) : ?>
					<li data-src="<?php $src = wp_get_attachment_image_src($post->ID, 'full'); echo $src[0]; ?>" data-html="<h1 class='image-title'><?php echo str_replace(array('_','-'),' ',$post->post_title);?></h1>">
						<a href="#">
							<?php echo wp_get_attachment_image($post->ID, 'thumbnail'); ?>
						</a>
					</li><?php endforeach; 
			?></ul>
		</div>
	</section>
</div>