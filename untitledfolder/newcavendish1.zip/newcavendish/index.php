<?php
/*
 * For purposes of Ajax this is the only wordpress page template in the theme 
 */
//Prepare document header
if($_GET["method"] != "ajax" ) {
	get_header(); 
	echo '<main role="main"><div class="wrapper">';
} else {
	$answer['title'] = wp_title('|',false);
	$answer['bodyclasses'] = implode(' ',get_body_class($class));
	ob_start();
}
?>

<?php 

//Prepare document content
if(is_front_page() || is_page(2) || is_page('events'))
	get_template_part('loop','home');
elseif(is_post_type_archive('menu'))
	get_template_part('loop','menulist');
elseif(is_page('menu-slider'))
	get_template_part('loop','menuslider');
elseif(is_page('gallery'))
	get_template_part('loop','gallery');
else
	get_template_part('loop');

//Prepare document footer
if($_GET["method"] != "ajax" ) { 
	//echo date("h:i:s");
	echo '</div></main>';
	get_footer(); 
} else {
	$answer['contents'] = ob_get_contents();
	ob_end_clean();
	echo json_encode($answer);
} ?>