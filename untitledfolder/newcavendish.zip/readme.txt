=!Bienvenido al readme de newcavendish!=

==Introduccion==
Mi intencion con este tema es hacer una demostracion, una demostracion de fuerza, de la fuerza del software libre.
Primero mostrar la fuerza de voluntad que supone para uno mismo, el creador del tema, centrarse en el desarrollo 
de un producto completo. Despues el esfuerzo de generar y mantener esa fuerza de voluntad aplicandola de forma
constructiva. Finalmente la fuerza de empuje que la comunidad de Wordpress ejerce sobre la web en tres direcciones:
libertad, igualdad y fraternidad.

==Consideraciones sobre este tema==
La vision de este tema es "Menos es newcavendish, mas es newcavendish tambien". El tema sin configurar debe ser sofisticado
y conocer las caracteristicas y aprovecharlas selectivamente debe ser capaz de generar experiencias unicas y personalizadas, 
es decir, la forma de dar protagonismo al contenido ha de ser proporcionando las caracteristicas para q este se desarrolle
y no quede constreñido por fetiches visuales.


==Estructura y jerarquia==
newcavendish evita intencionadamente los temas con innumerables plantillas con el objetivo de impedir la duplicacion del DOM. 
Para ello, la intencion es que cada bloque, cada etiqueta, aparezca una unica vez en las plantillas del tema. 
Otro objetivo es ser compatible con ajax, por ello la configuracion inicial (archivos + posts + paginas sin js extra)
del tema ha de proporcionar una experiencia ajax sencilla y total (sin hacks).

===Archivos===
Header + Footer
style.css + functions.php + app.js
Index {
	1. Title of the loop (For archives and search)	
	2. Loop > Posts {
		Entry Meta
		Entry Content
		Entry Comments
	}
	3. Pagination of the loop
}
Theme Widgets: Searchform + BG-box + Social buttons

The content should be displayed in a different way for archives and content by showing the meta differenctly