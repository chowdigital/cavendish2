var h,hh,device='phone';
/* secMapping "
 * 	if(the same) do nothing
	if (empty or home or events) replace all wrapper
	else load section 
}
*/

var resizeScreen = function() { //inicio y cambio de tamaÃ±o
	hh = $('header').height();
	h = $(window).height() - hh;
	if(device == 'phone') $('main').height(h);
	else if(device == 'desktop') $('.subsection').height($(document).height());
	$('#menuview').height(h - 20);
};

var CAVENDISH = CAVENDISH || {};


var getSec = function(href) { 
	var sec = href.replace(SITE_URL,'').replace(/[\w-\.:]*?\/?([a-z0-9-\/]*)\/(#|\?.*)?$/,'$1');
	if(sec=='/' || sec=='' || sec==SITE_URL+'/' || sec==SITE_URL) sec = 'home';
	return sec;
};
	

var openSec = function(e, forcehref,openAfter) {
	if(forcehref !== undefined) { // if openSec was called directly as a function
		var href = forcehref;
	} else { // or openSec was called by a html link
		var href = $(this).attr('href');
		// if we are dealing with an extenral link let's stop the function
		if (href.substring(0, 4) == "http" && href.substring(0, SITE_URL.length) != SITE_URL) return;
		else e.preventDefault();
		if(href=='#') return; 
	}

	var sec = getSec(href); // define sec
	// open the new section if it's not in the current one
	
	if($('body').attr('data-url').replace(/\/$/,'') != href.replace(/\/$/,'')) {
		$('.subsection').removeClass('show');
		$('#lightGallery-outer, #menuview').addClass('delete');
		setTimeout(function(){$('#lightGallery-outer, #menuview').remove()},600);;
		$('header nav').removeClass('open');
		// 1st step: change url:
		if(window.history && window.history.pushState) history.pushState({sec:sec}, sec, href);
		// 2nd step: process actions:
		var dontAjax=0,limit;
		if(sec=='home' || sec=='events') { // Are we replacing one of the 2 loop areas?
			$('main').unbind('click');
			if(sec=='home' && $('.loop').hasClass('loop-home') ||
			sec=='events' && $('.loop').hasClass('loop-events')) {
				// the area is already loaded, just close the subsection
				dontAjax = true;
				$('body').attr('data-url',href);
				setTimeout(function(){
					$('.subsection > *').remove();
					$('body').removeClass('open');
				},600);
			} else {
				// remove the different area, and open the new one
				$('.loop').addClass('delete').fadeOut(600,function(){
					$(this).remove();
				});
				if(sec == 'home') href = SITE_URL+'/home/'
				var callback = function(contents) {
					$('body').removeClass('open');
					$('main .wrapper').append(contents);
					if(openAfter !== undefined) {
						openSec(e,openAfter);
					}
				}
			}
		} else { // Are we replacing a subsection?
			var is_event = sec.replace(/\/([a-z0-9-\/]+)$/,'')=='event' ? true : false;
			if(is_event && !$('.loop').hasClass('loop-events')) { // an event should be opened in events area, open events
				openSec(e,SITE_URL + '/events/',href);
				dontAjax = true;
			} else if(!is_event && $('.loop').hasClass('loop-empty')) { //we're not in the correct area, open home
				openSec(e,SITE_URL + '/',href);
				dontAjax = true;
			}
			var callback = function(contents) {
				$('.subsection').addClass('no-overlay').animate({opacity: 0.9},'2000',function(){
					$(this).remove();
				});
				$('.subsection',contents).removeClass('show');
				$('main .wrapper .loop').append($('.subsection',contents));
				$('.subsection')[0].offsetHeight;
				$('.subsection').addClass('show');
				$('body').addClass('open');
			}
		}
		// 3rd step: process actions:
		if(!dontAjax){
				$('body').addClass('loading');
				$.get( href+'?method=ajax', function( data ) {
					data = JSON.parse(data);
					$('title').text(data.title);
					$('body').attr('class',data.bodyclasses);
					var contents = $.parseHTML( data.contents );
					if(sec!='gallery') $('a',contents).on('click', openSec);
					callback(contents);
					if(device == 'phone') $('main').height(h);
					$('body').attr('data-url',href);
					$('body').removeClass('loading');
					loadSec(sec);
				}, "html");
		}
	}
};

var loadSec = function(sec) {
	if(sec=='gallery') mobileGallery();
};
var toggleMenu = function(e) {
	e.preventDefault();
	$('header nav').toggleClass('open');
};

var mobileGallery = function() {
	var g = $('#post-gallery');
	$('ul',g).width(60*$('a',g).length);
	$('a',g).unbind('click').click(function(e){
		e.preventDefault();
		$('figure',g).fadeOut('fast',function(){$(this).remove()});
		var fig = '<figure style="background-image:url('+$(this).parent('li').data('src')+')"></figure>';
		$(fig).height(h-62).appendTo(g);
	});
	$('a:first',g).click();
};

window.onpopstate = function(event) {
	if(location.href.slice(-1) != '#') openSec(event,location.href);
};

$(window).resize(resizeScreen);

$(document).ready(function(){
    $('header a').on('click touchstart', openSec);
    $('main a').on('click', openSec);
    $('nav button').on('click touchstart', toggleMenu);
    resizeScreen();
    //cachearImg();
});
$(window).load(resizeScreen);



