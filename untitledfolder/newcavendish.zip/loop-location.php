<div class="loop loop-empty">
	<section class="subsection show">
<?php if (have_posts()): while (have_posts()) : the_post(); ?>
<?php //Prepare post vars
	$singular = is_singular();
	$thumb = the_compulsory_thumbnail('large','return'); //force thumb just when force content
	unset($format_normal,$format_image);
	if(has_post_format('image')) $format_image = true;
	else $format_normal = true; //standard, aside, page...
?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<h1>
			<?php $thumb_link = get_the_permalink(); ?>
			<?php if(!$singular) echo "<a href=\"$thumb_link\">";
			elseif(is_singular('menu')) {
				previous_post_link('<div style="float:right">%link</div>', '&gt;'); 
				next_post_link('<div style="float:left">%link</div>', '&lt;');
			} ?>
				<strong><?php the_title(); ?></strong>
			<?php if(!$singular) echo "</a>"; ?>
		</h1>
		<div class="post-content">
			<script src="http://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
			<script>
				var map;
				function initialize() {
					var styles = [{"stylers": [{ "visibility": "on" },{ "saturation": -100 }]},{"featureType": "landscape.man_made","stylers": [{ "visibility": "simplified" },{ "gamma": 0.4 }]},{"featureType": "road","elementType": "labels.icon","stylers": [{ "visibility": "simplified" }]},{"elementType": "labels","stylers": [{ "saturation": 100 }]},{"elementType": "labels.text","stylers": [{ "visibility": "on" },{ "saturation": -100 }]}];
					var mapOptions = {
						zoom: 17,
						center: new google.maps.LatLng(40.4297529, -3.687709),
						mapTypeId: google.maps.MapTypeId.ROADMAP,
						styles: styles,
						panControl: true,
						zoomControl: true,
						scaleControl: false,
						mapTypeControl: false,
						streetViewControl:false,
					};
					map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
					var image = SITE_URL+'/wp-content/themes/newcavendish/images/map_marker.png';
					var myLatLng = new google.maps.LatLng(40.4297529, -3.687709);
					var beachMarker = new google.maps.Marker({
						position: myLatLng,
						map: map,
						icon: image
					});
				}
				google.maps.event.addDomListener($('#map_canvas img')[0], 'click', initialize);
				google.maps.event.addDomListener(window, 'load', initialize);
			</script>
			<div id="map_canvas" style="width:100%; height: 100%"><img src="http://localhost/cavendish/wp-content/uploads/2014/09/The_Cavendish-35_Marylebone.png" /></div>
		</div>
		<?php wp_link_pages(array('before' => '<div class="post-pages">'.__('Pages:'),'after' => '</div>', 'next_or_number' => 'number')); ?>
		<?php if(is_singular('post')) echo '<a href="'.get_bloginfo('url').'/events/">Back to events</a>'; ?>
	</article>

	
<?php endwhile; ?>

<?php else: ?>
	<p><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'newcavendish' ); ?></p>
	<div class="search-area"><?php get_search_form(); ?></div>
<?php endif; ?>
	</section>
</div>