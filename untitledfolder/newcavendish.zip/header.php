<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title('|'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<script>var SITE_URL = '<?php echo bloginfo('url'); ?>';</script>
	<?php wp_head(); ?>
	<script>if( /Android.+mobile|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) == false) {document.write('<script src="<?php echo get_stylesheet_directory_uri() ?>/js/desktop.js">\x3C/script>\x3Clink rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() ?>/full.css?ver=4.0" type="text/css"/>'); document.documentElement.className = "preloasd";}</script>
	<!--[if lt IE 9]><script src="<?php echo get_stylesheet_directory_uri() ?>/js/html5shiv.js"></script><script>var ie8=1;</script><![endif]-->
</head>
<?php if($_GET["method"] != "ajax" AND !is_front_page() && !is_page(2) && !is_page('events') ) $class='open'; ?>
<body <?php body_class($class); ?> data-url="http://<?php echo $_SERVER["HTTP_HOST"].$_SERVER['REQUEST_URI']; ?>">
	<header class="header" role="banner">
		<div class="wrapper">
			<a id="logo" href="<?php echo home_url(); ?>/" title="Back to home" >
				<img src="<?php echo get_stylesheet_directory_uri() ?>/images/The_Cavendish-Marylebone.png" alt="<?php bloginfo('name'); ?>" />
			</a>
			<nav>
				<button id="menu-icon"><span class="bar1"></span><span class="bar2"></span><span class="bar3"></span></button>
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container_id'=>'top-menu', 'container_class'=>'menu-wrap' ) ); ?>
			</nav>
			<ul id="social">
				<li><a href="">Sign up to the newsletter</a></li>
				<li><a href="https://www.facebook.com/pages/35-New-Cavendish/1547377145481349?sk=info" target="_blank" class="social-fb">Facebook</a></li>
				<li><a href="https://twitter.com/35newcavendish" target="_blank" class="social-tw">Twitter</a></li>
				<li><a href="http://instagram.com/35newcavendish" target="_blank" class="social-ig">Instragram</a></li>
			</ul>
		</div>
	</header>
	<!-- /header -->